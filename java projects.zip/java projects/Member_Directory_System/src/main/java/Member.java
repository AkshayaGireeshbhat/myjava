public class Member {
    private int memberId;
    private String name;
    private String propertyNumber;
    private String contactNumber;
    private int numberOfDependents;

    public Member(int memberId, String name, String propertyNumber, String contactNumber, int numberOfDependents) {
        this.memberId = memberId;
        this.name = name;
        this.propertyNumber = propertyNumber;
        this.contactNumber = contactNumber;
        this.numberOfDependents = numberOfDependents;
    }

    public int getMemberId() {
        return memberId;
    }

    public String getName() {
        return name;
    }

    public String getPropertyNumber() {
        return propertyNumber;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public int getNumberOfDependents() {
        return numberOfDependents;
    }
}
