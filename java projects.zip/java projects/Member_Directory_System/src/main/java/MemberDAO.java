import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MemberDAO {
    private static final String JDBC_URL = "jdbc:sqlserver://172.16.51.64;\" + \"databaseName=231047010;encrypt=true;trustServerCertificate=true";
    private static final String USERNAME = "LEKHA";
    private static final String PASSWORD = "lekha@321";

    private static final String SELECT_ALL_MEMBERS = "SELECT * FROM Member_directory";
    private static final String INSERT_MEMBER = "INSERT INTO members (member_id, member_name, property, contact, number_of_dependences) VALUES (?, ?, ?, ?, ?)";

    public List<Member> getAllMembers() {
        List<Member> members = new ArrayList<>();

        try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
             PreparedStatement statement = connection.prepareStatement(SELECT_ALL_MEMBERS);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                int memberId = resultSet.getInt("member_id");
                String name = resultSet.getString("member_name");
                String propertyNumber = resultSet.getString("property");
                String contactNumber = resultSet.getString("contact");
                int numberOfDependents = resultSet.getInt("number_of_dependences");

                Member member = new Member(memberId, name, propertyNumber, contactNumber, numberOfDependents);
                members.add(member);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle database exception
        }

        return members;
    }

    public void addMember(Member member) {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
             PreparedStatement statement = connection.prepareStatement(INSERT_MEMBER)) {

            statement.setInt(1, member.getMemberId());
        	statement.setString(2, member.getName());
            statement.setString(3, member.getPropertyNumber());
            statement.setString(4, member.getContactNumber());
            statement.setInt(5, member.getNumberOfDependents());

            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle database exception
        }
    }

    // Implement methods for update and delete operations if needed
}
