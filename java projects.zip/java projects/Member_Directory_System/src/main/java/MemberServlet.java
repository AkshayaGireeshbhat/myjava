import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/memberServlet")
public class MemberServlet extends HttpServlet {
    private MemberDAO memberDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        // Initialize your DAO class here
        memberDAO = new MemberDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve all members
        List<Member> members = memberDAO.getAllMembers();

        // Set response content type
        response.setContentType("text/html");

        // Output members list to the client
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1>Members</h1>");
        out.println("<ul>");
        for (Member member : members) {
            out.println("<li>" + member.getName() + "</li>");
        }
        out.println("</ul>");
        out.println("</body></html>");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve request parameters
    	int memberId = Integer.parseInt(request.getParameter("memberId"));
        String name = request.getParameter("name");
        String propertyNumber = request.getParameter("propertyNumber");
        String contactNumber = request.getParameter("contactNumber");
        int numberOfDependents = Integer.parseInt(request.getParameter("numberOfDependents"));

        // Create a new member object
        Member newMember = new Member(memberId, name, propertyNumber, contactNumber, numberOfDependents);

        // Add the new member to the database
        memberDAO.addMember(newMember);

        // Redirect back to the doGet method to display updated member list
        response.sendRedirect(request.getContextPath() + "/memberServlet");
    }
}
