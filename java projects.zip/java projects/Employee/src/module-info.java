/**
 * 
 */
/**
 * @author MSIS
 *
 */
module Employee {
	requires java.sql;
}