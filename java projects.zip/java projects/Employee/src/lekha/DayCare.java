package lekha;

import java.util.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DayCare {
	
	private static final Connection NULL = null;
	public static void main(String args[]) {
		Connection con1 = NULL;
		Connection con2 = NULL;
	    
		Scanner sc = new Scanner(System.in);
		System.out.println("Book Details");
		try {
		
			String url="jdbc:sqlserver://172.16.51.64;"+" "+"databaseName=231047010;encrypt=true;trustServerCertificate=true";
			String username="lekha";
			String password="lekha@321";
			
			
			con1=DriverManager.getConnection(url,username,password);
			con1.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
			System.out.println("Connection 1 established");
			
			con2=DriverManager.getConnection(url,username,password);
			con2.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
			System.out.println("Connection 2 established");
			//con.setAutoCommit(false);
			

			
			System.out.println("Enter the ID of the book");
			int word = sc.nextInt();
			
			if(!checkBookExists(con1, word)) {
				System.out.println("Book with ID " + word + " not found.");
				return;
			}
			
			 int currentPrice = getBookPrice(con1, word);
	           System.out.println("Current price read using Connection 1: " + currentPrice);
	           
	           
	         currentPrice = getBookPrice(con2, word);
	         System.out.println("Current price read using Connection 2: " + currentPrice);
	           
	      
	           con1.setAutoCommit(false);
	           try {
	               // Update the price for first connection 
	        	   System.out.println("Enter the new price");
	        	   sc.nextLine();
	   			int newPrice = sc.nextInt();
	              // int newPrice1 = currentPrice + 10;
	               updateBookPrice(con1, word, newPrice);
	               System.out.println("Updated price using Connection 1: " + newPrice);
	               
	               if (newPrice < 0) {
	   				throw new IllegalArgumentException("Price cannot be negative ");
	   			}
	               // Commit the transaction for Connection 1
	               
	            
	               con1.commit();
	               //currentPrice = getBookPrice(con2, word);
		           //System.out.println("Current price read using Connection 2 after Connection 1 commit: " + currentPrice);
	           } catch (SQLException e) {
	               System.out.println("Error Occurred in Connection 1: " + e.getMessage());
	               con1.rollback();
	           } finally {
	               con1.setAutoCommit(true);
	           }
	           
	           //currentPrice = getBookPrice(con2, word);
	           //System.out.println("Current price read using Connection 2 after Connection 1 commit: " + currentPrice);
	           
	           
	           
	         
	           
	           
	           /*try {
	               // Update the price differently using the second connection (con2)
	               int newPrice2 = currentPrice - 5;
	               updateBookPrice(con2, word, newPrice2);
	               System.out.println("Updated price using Connection 2: " + newPrice2);
	               // Commit the transaction for Connection 2
	               con2.commit();
	           } catch (SQLException e) {
	               // Handle SQLException
	               System.out.println("Error Occurred in Connection 2: " + e.getMessage());
	               con2.rollback();
	           } finally {
	               // Set AutoCommit back to true for Connection 2
	               con2.setAutoCommit(true);
	           }

			System.out.println("Enter the new price");
			int newPrice = sc.nextInt();*/
			
			
			
			

			
		/*	//PreparedStatement stmt = con.prepareStatement("INSERT INTO BookMaster values(?,?,?)");
			//stmt.setInt(1, word);
			//stmt.setString(2, name);
			//stmt.setInt(3, cost);
			updateBookPrice(con, word, newPrice);
			System.out.println("updated succeesfully");
			//stmt.executeUpdate(); 
			con.commit();
			*/
			
		}catch(SQLException | IllegalArgumentException e) {
			System.out.println("Error Occurred:" + e.getMessage());
			
		}
			
			//System.out.println("Error Occured" + e.getMessage());
		 finally {
			 try {
	               // Close resources for both connections
	               if (con1 != null) {
	                   con1.close();
	                   System.out.println("Connection 1 Closed");
	               }
	               if (con2 != null) {
	                   con2.close();
	                   System.out.println("Connection 2 Closed");
	               }
	           } catch (SQLException closeException) {
	               closeException.printStackTrace();
				}
			}
	}
	 
	private static boolean checkBookExists(Connection con, int bookId) throws SQLException {
	       try (PreparedStatement checkStmt = con.prepareStatement("SELECT * FROM BookMaster WHERE BookID = ?")) {
	           checkStmt.setInt(1, bookId);
	           return checkStmt.executeQuery().next();
		}
	}
	
	private static int getBookPrice(Connection con, int bookId) throws SQLException {
		   // Read the current price of the book with the given ID
		   try (PreparedStatement readStmt = con.prepareStatement("SELECT BookPrice FROM BookMaster WHERE BookID = ?")) {
		       readStmt.setInt(1, bookId);
		       ResultSet resultSet = readStmt.executeQuery();
		       return resultSet.next() ? resultSet.getInt("BookPrice") : -1;
	       }
	   }
	
	private static void updateBookPrice(Connection con, int bookId, int newPrice) throws SQLException {
		   // Update the price of the book with the given ID using PreparedStatement
		   try (PreparedStatement updateStmt = con.prepareStatement("UPDATE BookMaster SET BookPrice = ? WHERE BookID = ?")) {
		       updateStmt.setInt(1, newPrice);
		       updateStmt.setInt(2, bookId);
		       updateStmt.executeUpdate();
	
			
		
	       }
	}
} 
